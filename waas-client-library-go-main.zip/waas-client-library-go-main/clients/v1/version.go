package v1

// version is the API version.
const version = "v1"
